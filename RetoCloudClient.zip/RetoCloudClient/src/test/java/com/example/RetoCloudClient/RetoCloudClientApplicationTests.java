package com.example.RetoCloudClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoCloudClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
